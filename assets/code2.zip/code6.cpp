#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int pid = fork();
    if(pid == 0){
        for (int i=1; i<=100; i++){
            cout << i << endl;
        }
    } else{
            wait(NULL);
            cout << "finished child" << endl;
        }
    return 0;
}

