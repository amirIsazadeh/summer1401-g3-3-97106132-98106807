#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int pid = fork();
    char * args[4];
    args[0] = "ls";
    args[1] = "-g";
    args[2] = "-h";
    args[3] = NULL;
    if(pid == 0){
        execvp(args[0], args);
    } else{
        wait(NULL);
        cout << "the end" << endl;
    }
    return 0;
}