#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int ret = fork();
    int temp = 3;
    if (ret==0){
        temp = 2;
        cout << "temp val in child process: " << temp << endl;
        return 23;
    } else{
        int rc = 10;
        wait(&rc);
        cout << "temp val in parent process: " << temp << endl;
    }
    return 0;
}

