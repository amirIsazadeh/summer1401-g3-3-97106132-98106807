#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int pid = fork();
    cout << "after first!!" << endl;
    pid = fork();
    cout << "after second!!" << endl;
    pid = fork();
    cout << "after third!!" << endl;
    return 0;
}


