#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    cout << "process id of parent: " << getpid() << endl;
    int pid = fork();
    if(pid == 0){
        cout << "process id of child before: " << getpid() << endl;
        sleep(1.5);
        cout << "process id of child after: " << endl;
        return 0;
    } else{
        sleep(1);
        cout << "end parent" << endl;
        return 1;
    }
    
    
    return 0;
}

