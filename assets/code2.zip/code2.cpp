#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
using namespace std;
int main(){
    cout << "now pid : " << getppid() << endl;
    return 0;
}