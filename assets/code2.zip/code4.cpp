#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int ret = fork();
    if (ret==0){
        cout << "child process!!" << endl;
    } else{
        cout << "parent process!!" << endl;
    }
    return 0;
}


