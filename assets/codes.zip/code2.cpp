#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main(){
    string input_s;
    cin >> input_s;
    string cmd = "cat /proc/" + input_s + "/cmdline";
    const char* str = &cmd[0u];
    system(str);
    cmd = "cat /proc/" + input_s + "/environ";
    str = &cmd[0u];
    system(str);
    cmd = "`cut -d \' \' -f1 /proc/" + input_s + "/statm`";
    str = &cmd[0u];
    return 0;
}