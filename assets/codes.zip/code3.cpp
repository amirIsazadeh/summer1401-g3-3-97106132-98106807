#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<bits/stdc++.h>
using namespace std;
int main(){
    fstream fstr("/proc/cpuinfo/");
    string l, model_name, cache_size, fr;
    while (getline(fstr, l)){
        int ind = l.find(":");
        if (ind > l.size()){
            continue;
        }
        string value = l.substr(ind+1, l.size());
        string key = l.substr(0, ind);

        if (key.find("model name") == 0){
            model_name = value;
        }
        if (key.find("cache size") == 0){
            cache_size = value;
        }
        if(key.find("cpu MHz") == 0){
            fr = value;
        }
    }

    fstr.close();
    cout << "fr " << fr << "\ncache size " << cache_size << "\nmodel name " << model_name;
    
    return 0;
}