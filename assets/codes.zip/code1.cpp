#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
using namespace std;
int main(){
    ifstream readfile;
    readfile.open("/proc/version");
    ofstream writefile;
    writefile.open("linux_version");
    writefile << readfile.rdbuf();
    readfile.close();
    writefile.close();
    return 0;
}