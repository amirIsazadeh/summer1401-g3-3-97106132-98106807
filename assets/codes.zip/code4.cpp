#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<bits/stdc++.h>
using namespace std;
int main(){
    fstream fstr("/proc/meminfo");
    string l;
    for(int i =0; i<3; i++){
        getline(fstr, l);
        cout << l << "\n";
    }

    return 0;
}