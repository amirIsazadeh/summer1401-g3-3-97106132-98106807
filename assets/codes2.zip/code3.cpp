#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int ret = fork();
    int a = 10;
    if (ret==0){
        a = 20;
        printf("value of a in child process is %d\n", a);
        return 23;
    } else{
        int rc = 10;
        wait(&rc);
        printf("value of 'a' in parent process is %d\n", a);
    }
    return 0;
}