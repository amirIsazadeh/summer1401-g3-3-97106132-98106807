#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    cout << "parent pid: " << getpid() << endl;
    int pid = fork();
    if(pid == 0){
        cout << "child pid before: " << getpid() << endl;
        sleep(1);
        cout << "child pid after: " << endl;
        return 0;
    } else{
        sleep(0.5);
        cout << "finished" << endl;
        return 1;
    }
    
    
    return 0;
}