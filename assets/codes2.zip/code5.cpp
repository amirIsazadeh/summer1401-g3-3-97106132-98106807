#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int pid = fork();
    cout << "after first fork.\n";
    pid = fork();
    cout << "after second fork.\n";
    pid = fork();
    cout << "after third fork.\n";
    return 0;
}