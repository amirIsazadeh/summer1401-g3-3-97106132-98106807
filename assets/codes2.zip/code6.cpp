#include<iostream>
#include<fstream>
#include<sys/syscall.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
using namespace std;
int main(){
    int pid = fork();
    if(pid == 0){
        int i = 1;
        for (i=1; i<=100; i++){
            cout << i << endl;
        }
    } else{
            wait(NULL);
            cout << "child process finished";
        }
    return 0;
}